
--
-- Estrutura da tabela `controle_acesso_drive`
--

CREATE TABLE `controle_acesso_drive` (
  `id` int(11) NOT NULL,
  `data_cadastro` varchar(200) NOT NULL,
  `colaborador` varchar(200) DEFAULT NULL,
  `caminho` varchar(200) DEFAULT NULL,
  `departamento` varchar(200) NOT NULL,
  `url_chamado` varchar(200) DEFAULT NULL,
  `usuario_cadastro` varchar(200) DEFAULT NULL,
  `obra` varchar(200) DEFAULT NULL,
  `D_E_L_E_T_E` varchar(2) DEFAULT NULL,
  `permissoes` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `controle_acesso_drive`
--
