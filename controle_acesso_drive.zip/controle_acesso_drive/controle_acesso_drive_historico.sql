-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 24-Jun-2024 às 15:00
-- Versão do servidor: 10.3.28-MariaDB
-- versão do PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tecnologia`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `controle_acesso_drive_historico`
--

CREATE TABLE `controle_acesso_drive_historico` (
  `id` int(11) NOT NULL,
  `data_cadastro` varchar(200) NOT NULL,
  `colaborador` varchar(200) DEFAULT NULL,
  `caminho` varchar(200) DEFAULT NULL,
  `departamento` varchar(200) NOT NULL,
  `chamados` varchar(200) DEFAULT NULL,
  `usuario_cadastro` varchar(200) DEFAULT NULL,
  `obra` varchar(200) DEFAULT NULL,
  `id_historico` varchar(10) NOT NULL,
  `D_E_L_E_T_E` varchar(2) DEFAULT NULL,
  `url_chamado` varchar(10200) DEFAULT NULL,
  `permissoes` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `controle_acesso_drive_historico`
--

