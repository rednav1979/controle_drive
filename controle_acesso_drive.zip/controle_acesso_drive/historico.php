<?php
session_start();
include('verifica_login.php');
?>	
<!DOCTYPE html>
<html>



 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
</head>



<img src=css/logo.png><br>
Hoje, 
<script Language="JavaScript">
<!--
mydate = new Date();
myday = mydate.getDay();
mymonth = mydate.getMonth();
myweekday= mydate.getDate();
weekday= myweekday; 
myear = mydate.getFullYear();

if(myday == 0)
day = " Domingo, " 

else if(myday == 1)
day = " Segunda - Feira, " 

else if(myday == 2)
day = " Terça - Feira, " 

else if(myday == 3)
day = " Quarta - Feira, " 

else if(myday == 4)
day = " Quinta - Feira, " 

else if(myday == 5)
day = " Sexta - Feira, " 

else if(myday == 6)
day = " Sábado, " 

if(mymonth == 0)
month = "Janeiro " 

else if(mymonth ==1)
month = "Fevereiro " 

else if(mymonth ==2)
month = "Março " 

else if(mymonth ==3)
month = "Abril " 

else if(mymonth ==4)
month = "Maio " 

else if(mymonth ==5)
month = "Junho " 

else if(mymonth ==6)
month = "Julho " 

else if(mymonth ==7)
month = "Agosto " 

else if(mymonth ==8)
month = "Setembro " 

else if(mymonth ==9)
month = "Outubro " 

else if(mymonth ==10)
month = "Novembro " 

else if(mymonth ==11)
month = "Dezembro " 

document.write("<font face=arial, size=2>"+ day);
document.write(myweekday+" de "+month+ "</font>");
document.write(myear);
// -->
</script>

<body>

    <section class="hero is-success is-fullheight">
	
        
            <div class="container has-text-centered">			
                
                    <h1 class="title has-text-grey">MENU DE ACESSO</h1>
					<h2 class="title has-text-grey"><font size=4>[Tecnologia da Informação]</font></h2>                   
                    <div class="box">
					<font color=red size=4> HISTORICO DE REGISTROS:</font>
                    <font size=2>
					
					

					
					<?php 
   include "sql_t.i.php";//conexão com o banco de dados
   
   @mysql_select_db($db);//selecione o banco de dados
    $id_fixo = $_GET['id'];
	
	$sqltudo = mysql_query("select  * FROM controle_acesso_drive_historico where D_E_L_E_T_E IS NULL and id_historico=('$id_fixo')")  or die(mysql_error());
           
           $colunas = mysql_num_rows($sqltudo);

	   print'<br>';	

	   print'<br>';   	
       print'<table border="1"   bordercolor="#00BFFF" >';
	   print'<tr>';
	   print'<td><b>ID</td>';	   	   
	   print'<td><b>CAMINHO</td>';	   
	   print'<td><b>COLABORADOR</td>';
	   print'<td><b>DEPARTAMENTO</td>';
	   print'<td><b>OBRA</td>';	   
	   print'<td><b>PERMISSOES</td>';	   
	   print'<td><b>SOLICITACAO</td>';
	   
	   
	   print'</tr></b>';
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
			$id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
			$caminho = @mysql_result($sqltudo, $j, "caminho");
			$colaborador = @mysql_result($sqltudo, $j, "colaborador");
			$departamento = @mysql_result($sqltudo, $j, "departamento");
			$obra = @mysql_result($sqltudo, $j, "obra");
			$permissoes = @mysql_result($sqltudo, $j, "permissoes");
			$url_chamado = @mysql_result($sqltudo, $j, "url_chamado");           
		  
	   /*print '<table border=1>';/*monta a tabela de eventos*/

	   print'<tr>';	       
	   print '<td>'.$id.'</td>';	       	  
	   //FIM DA INCLUSAO 
	  
	  
	   print '<td >'.$caminho.'</td>';	   
	   print '<td>'.$colaborador.'</td>';		   
	   print '<td>'.$departamento.'</td>';
	   print '<td>'.$obra.'</td>';
	   print '<td>'.$permissoes.'</td>';
	   
   // VERIFICA SE TEM TERMO E SE O EQUIPAMENTO NÃO É DA SEDE PARA COLOCAR O BOTAO DE UPLOAD
   if ($url_chamado == ""){  
		   
			print ' <td><form method="post" action="file_upload.php?id='.$id.'" enctype="multipart/form-data">
				<label>Arquivo:</label>
				<input type="file" name="arquivo" />
				<input type="submit" value="Enviar" />
				 </form></td>';
	}else{	
		print '<td><a href="url_chamado/'.$url_chamado.'"target="_blank"><img src="images/bolinha_verde.png" width=30 height=30></a>';	
	}
   

   
print '</tr>';	
	   }
   print'</table>';
   
?>					<a href="listar_pesquisa.php">[V O L T A R  ]</a>
                    </div>
                </div>
            </div>
        </div>
		
    </section>
	
	<br>

<br>


</body>

</html>


