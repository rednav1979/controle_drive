<?php
session_start();
include('verifica_login.php');
?>
<script language="javascript" type="text/javascript">

function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }	
</script>

<?php
$usuario_cadastro = $_SESSION['usuario'];
print '<p>';
print 'Olá: ';
print $usuario_cadastro;
print '<p>';
print 'Seja Bem Vindo(a).';
print '<br>';
?> 

<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="css/bulma.min.css" />
    <link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="stylesheet" href="./style.css">
	<link rel="stylesheet" href="./novo_menu.css">
</head>
<ul class="menu">
      <li title="home"><a href="#" class="menu-button home">menu</a></li>      
      <li title="Voltar"><a href="listar_pesquisa.php" class="volta">Voltar</a></li>  
	  <li title="Enviar e-mail"><a href="mailto:ti@lotisa.com.br" class="contact">Enviar e-mail</a></li>
    </ul>    
    <ul class="menu-bar">
        <li><a href="#" class="menu-button">Menu</a></li>
        <li><a href="listar.php">Home</a></li>		
       
    </ul>		
<!-- partial -->
<body>
 <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script><script  src="./novo_menu.js"></script>
<script language="javascript" type="text/javascript">

function maiuscula(z){
        v = z.value.toUpperCase();
        z.value = v;
    }	
</script>

<br>
<body> 
	


			<div class="column is-4 is-offset-4">
                    <h1 class="title has-text-grey">ATUALIZAÇÃO DE CUSTOS</h1><center>
					<h2 class="title has-text-grey"><font size=4>[Tecnologia da Informação]</font></h2> </center><br>
					
					<?php

//criar a conexÃ£o com o banco

include "sql_t.i.php";



if(isset($_POST['done'])){      
    $id_retorno = $_POST['id_retorno'];
    $sqltudo = mysql_query("select  * FROM controle_acesso_drive  where id= $id_retorno")  or die(mysql_error());           
    $colunas = mysql_num_rows($sqltudo);	  
    for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */        
        $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
        $caminho = @mysql_result($sqltudo, $j, "caminho");
        $colaborador = @mysql_result($sqltudo, $j, "colaborador");
        $departamento = @mysql_result($sqltudo, $j, "departamento");
        $permissoes = @mysql_result($sqltudo, $j, "permissoes");
        $obra = @mysql_result($sqltudo, $j, "obra");
        $url_chamado = @mysql_result($sqltudo, $j, "url_chamado");  
    }
    
    $sql2 = mysql_query("INSERT INTO `controle_acesso_drive_historico`(`data_cadastro`,`caminho`,`colaborador`, `departamento`, `obra`, `url_chamado`,`usuario_cadastro`,`id_historico`,`permissoes`) VALUES (now(),'$caminho','$colaborador','$departamento ', '$obra', '$url_chamado','$usuario_cadastro','$id_retorno','$permissoes')") or die(mysql_error());
    
    
    //INICIO DE UPDATE DOS CAMPOS
    $caminho_retorno = $_POST['caminho'];
    $colaborador_retorno = $_POST['colaborador'];
	$departamento_retorno = $_POST['departamento'];
    $obra_retorno = $_POST['obra'];
    $permissoes_retorno = $_POST['permissoes'];
    $url_chamado_retorno = $_POST['url_chamado'];        
	$usuario_cadastro_retorno = $_SESSION['usuario'];
    
	$sql_update = mysql_query("update `controle_acesso_drive` set caminho='$caminho_retorno',colaborador ='$colaborador_retorno',departamento='$departamento_retorno',obra='$obra_retorno',url_chamado='$url_chamado_retorno',usuario_cadastro='$usuario_cadastro_retorno',permissoes='$permissoes_retorno' where id = '$id_retorno'") or die(mysql_error()); 		   
    
	   
            if($sql2){
                print '<script> alert("Historico Gravado  com sucesso!")</script>';
              } else{
                print '<script> alert("Não foi possivel cadastrar Histórico!!!")</script>';
              }

              if($sql_update){
                print '<script> alert("Atualização  Gravada  com sucesso!")</script>';
              } else{
                print '<script> alert("Não foi possivel Gravar Atualização!!!")</script>';
              }

    }

    

?>
					

                    <div class="box">


<font size=1>  
  <form name="form1" action="listar_pesquisa_update.php" method="POST">


<p align=left>
				   <img src=css/logo.png><br></p>

					
				<?php 
   include "sql_t.i.php";//conexão com o banco de dados   
   @mysql_select_db($db);//selecione o banco de dados
	$id_retorno = $_GET['id'];    
    if ($id_retorno ==''){    

    }else{  
    
	$sqltudo = mysql_query("select  * FROM controle_acesso_drive  where id= $id_retorno ")  or die(mysql_error());           
    $colunas = mysql_num_rows($sqltudo);
           for($j = 0; $j < $colunas; $j++){/*caso no mesmo dia tenha mais eventos continua imprimindo */
            $id = @mysql_result($sqltudo, $j, "id");/*pegando os valores do banco referente ao evento*/
            $caminho = @mysql_result($sqltudo, $j, "caminho");
            $colaborador = @mysql_result($sqltudo, $j, "colaborador");
            $departamento = @mysql_result($sqltudo, $j, "departamento");
            $obra = @mysql_result($sqltudo, $j, "obra");
            $permissoes = @mysql_result($sqltudo, $j, "permissoes");
            $url_chamado = @mysql_result($sqltudo, $j, "url_chamado");  
		   
           }
    }   
	   

?>

                               <div class="field">
                                <div class="control">                                    									
									
                                    <input type="text" placeholder="caminho" name="caminho"  value="<?php echo $caminho; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
									<input type="text" placeholder="colaborador" name="colaborador" value="<?php echo $colaborador; ?>"class="input is-large" onkeyup="maiuscula(this)"/>									
									<input type="text" placeholder="departamento" name="departamento" value="<?php echo $departamento; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    <input type="text" placeholder="obra" name="obra" value="<?php echo $obra; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
                                    
                                    <select name="permissoes" class="input is-large"   autofocus="" >									
                                    <option>SELECIONE</option>
								        <option>LEITURA</option>									   
                                        <option>GRAVACAO</option>									   
                                        <option><?php echo $permissoes;?></option>								
                                        <option value="<?php echo $permissoes;?>" selected><?php echo $permissoes;?></option>
										   </select>	

                                    <input type="text" placeholder="url_chamado" name="url_chamado" value="<?php echo $url_chamado; ?>" class="input is-large" onkeyup="maiuscula(this)"/>
									<td><input type="hidden" enable="false" name="id_retorno" value="<?php echo $id_retorno; ?>" size=6/></td></tr>

                                </div>
                            </div>
                            <?php
                            if ($id_retorno ==''){
                                print '<font size=4>';
                                print '<center>';
                                print '<a href=listar_pesquisa.php>VOLTAR</a>';
                            }else{
                            print '<button type="submit" onclick="" class="button is-block is-link is-large is-fullwidth">ATUALIZAR</button><input type="hidden" name="done"  value="" />';
                            }
                            ?>
                        </form>

						
						

						
                    </div>
                </div>
            </div>
        </div>
    </section>
	

</body>

</html>